-- Info --

This pack is a Beta version and certainly contains a lot of issues.
Please write Anfauglir#7485 on Discord or leave a comment on the
CurseForge page if you encounter any problems.


-- Creator --

Valaron/Anfauglir/Jakob


-- Credits --

- Noppes (for making custom parts possible in MPM)